#!/bin/sh
java -classpath src/java111/$1 $2 $3 $4
