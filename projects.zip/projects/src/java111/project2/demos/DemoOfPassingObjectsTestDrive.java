/**
 *  A test drive class
 *
 *@author    eknapp
 */
public class DemoOfPassingObjectsTestDrive {

    /**
     *  The main program for the TestDrive class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        
        DemoOfPassObjectByValue demo = new DemoOfPassObjectByValue();
        demo.run();

    }
}
