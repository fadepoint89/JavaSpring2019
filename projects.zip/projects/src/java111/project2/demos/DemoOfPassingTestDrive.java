/**
 *  My test drive template
 *
 *@author    eknapp
 */
public class DemoOfPassingTestDrive {

    /**
     *  The main program for the TestDrive class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {
        
        DemoOfPassByValue one = new DemoOfPassByValue();
        one.run();

    }
}
