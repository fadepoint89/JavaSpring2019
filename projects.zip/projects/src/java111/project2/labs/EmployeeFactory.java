public class EmployeeFactory {
    Employee[] employeeList;

    public void setup() {
        employeeList = new Employee[2];
        employeeList[0] = new Employee();
        employeeList[1] = new Employee();
        employeeList[2] = new Employee();
    }

    public void runWhile() {
        int counter = 3;

        while (counter > 0) {
            
        }
    }

}
