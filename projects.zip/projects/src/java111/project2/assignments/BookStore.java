/** This class represents a bookstore.
 *  It will be used to emphasize
 *  Unit 2 concepts and help you prepare
 *  for Project 2.
 *  @author //TODO add your name here
 */

public class BookStore {

    // TODO Create the following instance variable, but do not instantiate it.
    // an array that will hold book objects

    // TODO Create a public set method for the array

    // TODO Create a method to calculate and return the total distance our books take up

    /*  TODO Create a method that prints out our book store's information
      *  1) Loop through the array and call the display() method on each book
      *  2) Print the total distance the books take up.
      */

    /* TODO Remember to include descriptive comments before each method explaining
     *  what the method does. Be sure to include details about what parameters the
     * methods take and what they return, if anything.
     */

}
