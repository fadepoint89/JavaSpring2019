/** This class creates a bookstore and then fills it with books.
 *  It will be used to emphasize
 *  Unit 2 concepts and help you prepare
 *  for Project 2.
 *  @author //TODO add your name here
 */

public class BookStoreBuilder {
    // TODO Create a private instance variable to hold a BookStore object,
    // but do not instantiate it yet

    /* TODO Create a method to create books
     *  1) Instantiate a few book objects and place them into a LOCAL array
     *  2) Set each books's instance variables using the book's set methods
     *  3) Set the local array of books into the BookStore's array of books using
     *     the set method
     */

     /** TODO Create a run method that
      *  1) Instantiates a new BookStore object and assigns it to the
      *     instance variable
      *  2) Calls the method to create the books
      *  3) Calls the method in the BookStore to calculate total book distance
      *  4) Calls the method in the BookStore to display the information
      *     about our books
      */

      // TODO remember to add descriptive comments!

}
