/**
 * Test drive class file for LabTwoOneA.java
 *
 * @author Jared Wesolaski
 */
public class LabTwoOneATestDrive {
	
	public static void main(String[] args) {
		LabTwoOneA test = new LabTwoOneA();
		
		test.multiply();
		test.divide();
	}
}