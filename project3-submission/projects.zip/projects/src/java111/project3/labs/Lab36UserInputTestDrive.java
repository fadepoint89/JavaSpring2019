/**
* Test Drive class file for Lab36UserInput.java
*
* @author Jared Wesolaski
*/
public class Lab36UserInputTestDrive {
    
    public static void main(String args[]) {
        Lab36UserInput test = new Lab36UserInput();
        test.run();
    }
    
}