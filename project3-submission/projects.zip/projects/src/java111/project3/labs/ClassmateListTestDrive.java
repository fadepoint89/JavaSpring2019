public class ClassmateListTestDrive{
    
    public static void main(String args[]) {
        ClassmateList test = new ClassmateList();
        
        test.run();
    }
    
}