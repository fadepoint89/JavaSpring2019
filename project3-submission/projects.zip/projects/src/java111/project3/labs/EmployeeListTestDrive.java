public class EmployeeListTestDrive {
    
    public static void main(String args[]) {
        EmployeeList test = new EmployeeList();
        
        test.run();
    }
    
}