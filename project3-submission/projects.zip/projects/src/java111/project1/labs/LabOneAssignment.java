/**
 * This is the class file for Lab 1.1
 *
 * @author Jared Wesolaski
 *
 */
public class LabOneAssignment {

    public static void main(String[] args)  {
        int age = 25;
        String name = "Fred";

        System.out.println(age);
        System.out.println(name);
    }
}
