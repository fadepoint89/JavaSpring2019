/**
 * This is the test drive class file for Assignment 2 Part 2.
 *
 * @author Jared Wesolaski
 */
public class Assignment2TestDrive {

    
    public static void main(String[] args) {
        Assignment2Debug mainProgram = new Assignment2Debug();

        mainProgram.fullName();
    }
}
