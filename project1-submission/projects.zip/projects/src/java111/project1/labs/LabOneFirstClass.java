/**
 * This is the class for Lab 1
 *
 * @author Jared Wesolaski
 *
 */
public class LabOneFirstClass {

    /**
     * This is the main method for this class which will
     * output a welcome message.
     *
     * @param args
     */
    public static void main(String[] args) {

        System.out.println("Hi there!");

    }

}
