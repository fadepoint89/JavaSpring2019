public class LabThree {
	
	public void sayHello(String name) {
		System.out.println("Hello there " + name);
	}
	
	public void sayHelloAgain(String name2, int counter) {
		while (counter > 0) {
			System.out.println("Hello there " + name2);
			counter = counter - 1;
		}
	}
	
}