public class LabThreeTestDrive{
	
	public static void main(String[] args) {
		LabThree hello1 = new LabThree();
		
		hello1.sayHello("Fred");
		hello1.sayHello("Barney");
		hello1.sayHello("Wilma");
		hello1.sayHello("Betty");
		
		// Separate the two methods' display
		System.out.println("");
		
		hello1.sayHelloAgain("Wilma", 5);
	}
	
}