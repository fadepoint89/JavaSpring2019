/** Final test drive class to create an instance of Process Students and display
 *  the results. 
 *
 *  @author Jared Wesolaski
 */
public class StudentTestDrive {


    public static void main(String[] args) {
        // Create an instance of ProcessStudents and run it
        ProcessStudents processStudentsMain = new ProcessStudents();

        processStudentsMain.runStudentProcessing();

    }
}
