public class InvoiceTestDrive {


    public static void main(String[] args) {

        ProcessInvoice newInvoice = new ProcessInvoice();

        newInvoice.runProcess();
    }
}
