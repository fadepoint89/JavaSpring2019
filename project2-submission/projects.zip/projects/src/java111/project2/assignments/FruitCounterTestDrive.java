/**
* Class for Module 2 Assignment 2 that will create
* an instance of FruitCounter and run it
*
* @author Jared Wesolaski
*/
public class FruitCounterTestDrive {

    /**
    * Main method to run the program
    * @param args
    */
    public static void main(String[] args) {
        FruitCounter program = new FruitCounter();

        program.run();
    }

}
