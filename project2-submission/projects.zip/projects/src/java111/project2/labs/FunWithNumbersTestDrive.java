public class FunWithNumbersTestDrive {

    public static void main(String[] args) {
        FunWithNumbers program = new FunWithNumbers();

        program.run();
    }

}
