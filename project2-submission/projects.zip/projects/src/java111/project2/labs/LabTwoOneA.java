/**
 * Class file for Lab 1 of Project2
 *
 * @author Jared Wesolaski
 */
public class LabTwoOneA {
	
	int number1 = 5;
	long number2 = 78;
	double number3 = 2.7;
	
	public void multiply() {
		System.out.println(number1 * number2 * number3);
	}
	
	public void divide() {
		System.out.println(number2 / number1);
	}
	
}