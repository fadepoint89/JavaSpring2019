/**
 * This is the class file for Part 4 of Lab 4
 *
 * @author Jared Wesolaski
 *
 */
public class Lion {

    /**
     *  Method that can be called that will output a roar.
     */
    public void roar() {
        System.out.println("Roar!");
    }
}
