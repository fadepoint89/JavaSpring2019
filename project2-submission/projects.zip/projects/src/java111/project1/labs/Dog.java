/**
 *  The Dog class which we will use to make our first objects! Woo Hoo!!
 *
 *@author    eknapp
 */
public class Dog {

    int     size;
    String  breed;
    String  name;


    /**
     *  This method is the code for the bark action
     */
    void bark() {
        System.out.println("Ruff! Ruff!");
    }

}