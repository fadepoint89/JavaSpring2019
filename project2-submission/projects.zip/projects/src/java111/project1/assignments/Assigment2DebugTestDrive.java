/**
 * This is the test drive file for Assignment 2 Part 2
 *
 * @author Jared Wesolaski
 */
public class Assignment2DebugTestDrive {

    /**
     * Method that will instantiate an Assignment2Debug object
     * and run the fullName() method on it
     *
     * @param args
     */
    public static void main(String[] args) {
        Assignment2Debug testFixed = new Assignment2Debug();

        testFixed.fullName();
    }
}
