#!/bin/sh -x
javac -classpath src/java111/$1 src/java111/$1/$2.java
